package com.tarefa.repository;

import org.springframework.stereotype.Repository;

@Repository
public class TaskRepository {
    // Simulação de acesso a dados
}
