package com.tarefa.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tarefas")
public class TaskController {
    // Métodos CRUD aqui
}
