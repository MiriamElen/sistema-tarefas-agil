package com.tarefa.model;

public class Task {
    private Long id;
    private String titulo;
    private String descricao;
    private String prioridade;
    private String status;

    // Getters e Setters
}
