package com.tarefa;

import org.junit.jupiter.api.Test;

public class TaskControllerTest {
    @Test
    void testeSimples() {
        assert true;
    }
}
