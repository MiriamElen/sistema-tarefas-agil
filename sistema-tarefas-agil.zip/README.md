# ✅ Sistema de Gerenciamento Ágil de Tarefas

## 📌 Objetivo do Projeto
Este projeto tem como objetivo desenvolver um sistema web para gerenciamento de tarefas baseado em metodologias ágeis...

(Conteúdo completo aqui como mostrado antes)
